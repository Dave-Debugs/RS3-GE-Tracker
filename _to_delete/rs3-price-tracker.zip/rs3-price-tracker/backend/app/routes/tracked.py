from __future__ import annotations

import time

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from ..db.repository import Repository
from ..deps import get_repo, get_scheduler
from ..services.analytics import analyze_trend, merge_sources, pct_change, price_at_or_before
from .helpers import icon_url

router = APIRouter(prefix="/api/tracked", tags=["tracked"])


class TrackRequest(BaseModel):
    item_id: int


class FavoriteRequest(BaseModel):
    favorite: bool


@router.get("")
def list_tracked(repo: Repository = Depends(get_repo)) -> dict:
    now = int(time.time())
    tracked = repo.tracked()
    latest = repo.get_latest([t["item_id"] for t in tracked])
    out = []
    for t in tracked:
        iid = t["item_id"]
        points = merge_sources(repo.get_price_history(iid, now - 30 * 86400))
        lp = latest.get(iid)
        current = None
        updated = None
        if lp:
            prices = [p for p in (lp.get("high"), lp.get("low")) if p]
            current = round(sum(prices) / len(prices)) if prices else None
            updated = max(lp.get("high_time") or 0, lp.get("low_time") or 0) or None
        if current is None and points:
            current = points[-1].get("average_price")
            updated = points[-1]["timestamp"]
        trend = analyze_trend(points)
        vol_24h = sum(
            p.get("volume") or 0 for p in points if p["timestamp"] >= now - 86400
        )
        out.append({
            "item_id": iid,
            "name": t.get("name") or f"Item {iid}",
            "icon_url": icon_url(t.get("icon"), iid),
            "members": bool(t.get("members")),
            "favorite": bool(t.get("favorite")),
            "current_price": current,
            "change_24h": pct_change(price_at_or_before(points, now - 86400), current),
            "change_7d": pct_change(price_at_or_before(points, now - 7 * 86400), current),
            "change_30d": pct_change(
                price_at_or_before(points, now - 30 * 86400)
                or (points[0].get("average_price") if points else None),
                current,
            ),
            "trend": trend.classification,
            "volume_24h": int(vol_24h),
            "last_updated": updated,
            "backfilled": bool(t.get("backfilled")),
        })
    return {"tracked": out}


@router.post("", status_code=201)
def add_tracked(body: TrackRequest, repo: Repository = Depends(get_repo),
                scheduler=Depends(get_scheduler)) -> dict:
    if not repo.get_item(body.item_id):
        raise HTTPException(404, f"Unknown item id {body.item_id}")
    added = repo.add_tracked(body.item_id)
    if added and scheduler is not None:
        scheduler.trigger_now()  # kick off backfill promptly
    return {"item_id": body.item_id, "added": added}


@router.delete("/{item_id}")
def remove_tracked(item_id: int, repo: Repository = Depends(get_repo)) -> dict:
    removed = repo.remove_tracked(item_id)
    if not removed:
        raise HTTPException(404, "Item is not tracked")
    return {"item_id": item_id, "removed": True}


@router.put("/{item_id}/favorite")
def set_favorite(item_id: int, body: FavoriteRequest,
                 repo: Repository = Depends(get_repo)) -> dict:
    if item_id not in repo.tracked_ids():
        raise HTTPException(404, "Item is not tracked")
    repo.set_favorite(item_id, body.favorite)
    return {"item_id": item_id, "favorite": body.favorite}
