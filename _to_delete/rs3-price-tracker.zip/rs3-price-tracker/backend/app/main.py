"""FastAPI application entry point.

Run with:  uvicorn app.main:app --port 8000   (from the backend/ directory)
"""
from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .api_client.client import RS3PriceClient
from .collector.collector import Collector
from .collector.scheduler import CollectorScheduler
from .config import DATABASE_PATH, DEFAULT_SETTINGS
from .db.database import Database
from .db.repository import Repository
from .logging_config import setup_logging
from .routes import (
    export, icons, items, movers, prices, settings, stats, status, tracked,
)

log = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    setup_logging()
    log.info("RS3 GE Tracker backend starting (db=%s)", DATABASE_PATH)

    db = Database(DATABASE_PATH)
    repo = Repository(db)
    app_settings = repo.get_settings(DEFAULT_SETTINGS)
    client = RS3PriceClient(user_agent=app_settings["user_agent"])
    collector = Collector(repo, client)
    scheduler = CollectorScheduler(repo, collector)

    app.state.db = db
    app.state.repo = repo
    app.state.client = client
    app.state.collector = collector
    app.state.scheduler = scheduler

    if app_settings.get("collector_autostart", "true") == "true":
        scheduler.start()
    else:
        log.info("Collector autostart disabled in settings")

    yield

    log.info("RS3 GE Tracker backend shutting down")
    await scheduler.stop()
    client.close()
    db.close()


def create_app() -> FastAPI:
    app = FastAPI(
        title="RS3 Grand Exchange Tracker",
        version="1.0.0",
        lifespan=lifespan,
    )
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
        allow_methods=["*"],
        allow_headers=["*"],
    )
    for module in (items, tracked, prices, stats, movers, settings, status,
                   export, icons):
        app.include_router(module.router)

    @app.get("/api/health")
    def health() -> dict:
        return {"status": "ok"}

    return app


app = create_app()
