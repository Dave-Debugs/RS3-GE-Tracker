import type { StatusInfo } from "../types";
import { relativeTime } from "../lib/format";

interface Props {
  status: StatusInfo | null;
  onOpenSettings: () => void;
  onCollectNow: () => void;
}

export default function Header({ status, onOpenSettings, onCollectNow }: Props) {
  const online = status?.api_online ?? false;
  return (
    <header className="header">
      <div className="header-title">
        <span className="header-coin" aria-hidden>⬤</span>
        <div>
          <h1>RS3 Grand Exchange Tracker</h1>
          <span className="header-sub">Rolling 30-day market history</span>
        </div>
      </div>
      <div className="header-status">
        <span className={`pill ${online ? "pill-online" : "pill-offline"}`}>
          <span className="dot" /> API {online ? "ONLINE" : "OFFLINE"}
        </span>
        <span className="status-item" title="Last successful collection">
          Last update: <b>{relativeTime(status?.last_update)}</b>
        </span>
        <span className="status-item" title="Next scheduled collection">
          Next: <b>{relativeTime(status?.next_update)}</b>
        </span>
        <button className="btn btn-ghost" onClick={onCollectNow} title="Collect prices now">
          ↻ Refresh
        </button>
        <button className="btn btn-ghost" onClick={onOpenSettings} title="Settings">
          ⚙ Settings
        </button>
      </div>
    </header>
  );
}
