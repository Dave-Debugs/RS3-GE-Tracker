import { useState } from "react";
import type { TrackedItem } from "../types";
import {
  changeClass, formatGP, formatGPExact, formatPct, formatVolume, relativeTime,
} from "../lib/format";

interface Props {
  items: TrackedItem[];
  selectedIds: Set<number>;
  focusedId: number | null;
  onToggleChart: (id: number) => void;
  onFocus: (id: number) => void;
  onFavorite: (id: number, fav: boolean) => void;
  onRemove: (id: number) => void;
}

const TREND_ICON: Record<string, string> = {
  "Strongly Rising": "▲▲",
  Rising: "▲",
  Neutral: "◆",
  Falling: "▼",
  "Strongly Falling": "▼▼",
};

export default function TrackedList({
  items, selectedIds, focusedId, onToggleChart, onFocus, onFavorite, onRemove,
}: Props) {
  const [filter, setFilter] = useState("");
  const shown = items.filter((i) =>
    i.name.toLowerCase().includes(filter.toLowerCase())
  );
  return (
    <section className="card tracked-card">
      <div className="card-head">
        <h2>Tracked Items <span className="count-badge">{items.length}</span></h2>
        {items.length > 3 && (
          <input
            className="mini-filter"
            placeholder="Filter…"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
          />
        )}
      </div>
      {!items.length && (
        <p className="muted empty-hint">
          Nothing tracked yet — search an item above and hit <b>+ Track</b>.
        </p>
      )}
      <div className="tracked-rows">
        {shown.map((item) => {
          const trendCls =
            item.trend.includes("Rising") ? "up"
            : item.trend.includes("Falling") ? "down" : "neutral";
          return (
            <div
              key={item.item_id}
              className={
                "tracked-row" +
                (focusedId === item.item_id ? " focused" : "") +
                (selectedIds.has(item.item_id) ? "" : " dimmed")
              }
              onClick={() => onFocus(item.item_id)}
            >
              <input
                type="checkbox"
                className="row-check"
                title="Show on chart"
                checked={selectedIds.has(item.item_id)}
                onClick={(e) => e.stopPropagation()}
                onChange={() => onToggleChart(item.item_id)}
              />
              {item.icon_url ? (
                <img src={item.icon_url} alt="" className="item-icon" loading="lazy"
                     onError={(e) => ((e.target as HTMLImageElement).style.visibility = "hidden")} />
              ) : <span className="item-icon placeholder" />}
              <div className="tracked-name">
                <span className="name">{item.name}</span>
                <span className="sub">
                  {item.backfilled ? relativeTime(item.last_updated) : "backfilling…"}
                  {" · vol "}{formatVolume(item.volume_24h)}
                </span>
              </div>
              <div className="tracked-price" title={formatGPExact(item.current_price)}>
                {formatGP(item.current_price)}
              </div>
              <div className="tracked-changes">
                <span className={changeClass(item.change_24h)} title="24-hour change">
                  {formatPct(item.change_24h)}
                </span>
                <span className={changeClass(item.change_7d)} title="7-day change">
                  {formatPct(item.change_7d)}
                </span>
                <span className={changeClass(item.change_30d)} title="30-day change">
                  {formatPct(item.change_30d)}
                </span>
              </div>
              <span className={`trend-tag ${trendCls}`} title={item.trend}>
                {TREND_ICON[item.trend] ?? "◆"} {item.trend}
              </span>
              <div className="row-actions" onClick={(e) => e.stopPropagation()}>
                <button
                  className={"icon-btn" + (item.favorite ? " fav" : "")}
                  title={item.favorite ? "Unfavorite" : "Favorite"}
                  onClick={() => onFavorite(item.item_id, !item.favorite)}
                >★</button>
                <button
                  className="icon-btn danger"
                  title="Stop tracking"
                  onClick={() => onRemove(item.item_id)}
                >✕</button>
              </div>
            </div>
          );
        })}
      </div>
      <p className="muted legend-hint">24H / 7D / 30D changes · checkbox = show on chart · click a row for stats</p>
    </section>
  );
}
