import type { ItemStats, TrendInfo } from "../types";
import { changeClass, formatGP, formatGPExact, formatPct, formatVolume } from "../lib/format";

interface Props {
  name: string | null;
  stats: ItemStats | null;
  trend: TrendInfo | null;
}

export default function StatsPanel({ name, stats, trend }: Props) {
  if (!name || !stats) {
    return (
      <section className="card stats-card">
        <h2>Price Statistics</h2>
        <p className="muted empty-hint">Select a tracked item to see its stats.</p>
      </section>
    );
  }
  const rows: [string, string, string?][] = [
    ["Current price", formatGPExact(stats.current_price)],
    ["24H change", formatPct(stats.change_24h), changeClass(stats.change_24h)],
    ["7D change", formatPct(stats.change_7d), changeClass(stats.change_7d)],
    ["30D change", formatPct(stats.change_30d), changeClass(stats.change_30d)],
    ["30D high", formatGP(stats.high_30d)],
    ["30D low", formatGP(stats.low_30d)],
    ["30D average", formatGP(stats.average_30d)],
    ["30D median", formatGP(stats.median_30d)],
    ["30D volatility", stats.volatility_30d != null ? `${stats.volatility_30d}%` : "—"],
    ["Volume (30D)", formatVolume(stats.total_volume)],
  ];
  const trendCls = trend?.classification.includes("Rising") ? "up"
    : trend?.classification.includes("Falling") ? "down" : "neutral";
  return (
    <section className="card stats-card">
      <h2>{name}</h2>
      {trend && (
        <div className={`trend-banner ${trendCls}`}>
          <span className="trend-label">{trend.classification}</span>
          <span className="trend-detail" title="Linear regression slope over recorded history">
            slope {trend.slope_pct_per_day > 0 ? "+" : ""}{trend.slope_pct_per_day}%/day
            {" · "}momentum {formatPct(trend.momentum_pct)}
            {" · "}R² {trend.r_squared}
          </span>
        </div>
      )}
      <dl className="stats-grid">
        {rows.map(([label, value, cls]) => (
          <div key={label} className="stat">
            <dt>{label}</dt>
            <dd className={cls ?? ""}>{value}</dd>
          </div>
        ))}
      </dl>
      {trend && (
        <p className="muted trend-note">
          Descriptive statistics over {trend.points_used} recorded points — not a
          prediction. Short MA {formatGP(trend.short_ma)} vs long MA {formatGP(trend.long_ma)};
          volatility {trend.volatility_pct}% per point.
        </p>
      )}
    </section>
  );
}
